def compute_total(items):
    return sum(price * quantity for price, quantity in items)
