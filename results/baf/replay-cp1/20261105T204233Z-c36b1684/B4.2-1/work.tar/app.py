from pricing import compute_total

def invoice(items):
    return compute_total(items)
