# Pricing

Use compute_total(items) or invoice(items).
